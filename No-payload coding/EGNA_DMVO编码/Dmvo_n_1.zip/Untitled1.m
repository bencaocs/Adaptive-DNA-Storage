d=[[2	0	2	0	0	1	2	3]
[2	0	2	0	0	1	2	3]
[2	0	2	0	0	1	2	3]];
e=[2	0	2	0	1	1	2	3];
%C=Editconstraint(e,d)
c=norun(e)